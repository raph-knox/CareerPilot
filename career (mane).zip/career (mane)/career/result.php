<?php
  if(isset($_POST['submit']))
{
	$a=$_POST['a'];
	$b=$_POST['b'];
    
    $t = 14;

if ($a < $b) {
  echo "Have a good day!";
}

}
    ?>